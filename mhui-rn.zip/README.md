## 米家扩展程序中使用的 React Native UI 组件

## [组件文档](/ComponentsOverview.md)

## [变更日志](/CHANGELOG.md)

## 注意，在非 miot-plugin-sdk 中使用，需要安装一下依赖
`npm install react-native-indicators@0.13.0 react-native-iphone-x-helper@1.2.0 react-native-linear-gradient@2.5.4 react-native-progress@3.5.0 react-native-root-siblings@4.0.6 react-native-shadow@1.2.2 react-native-slider@0.11.0 react-native-svg@9.5.3 react-native-swiper@1.6.0-nightly.5 react-native-ui-kitten@3.1.2 react-navigation@2.16.0`
